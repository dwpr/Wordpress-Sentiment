<?php
/*
Plugin Name: TAnalyzer
Description: Aplikasi atau library untuk analisis sentimen dengan metode KNN. Aplikasi atau library ini disusun untuk memenuhi kuliah di <a href="http://uad.ac.id" target="_blank">Univeristas Ahmad Dahlan</a> sebagai pelengkap Tugas Akhir.<br><br> This app just re-mod and testing build from <b>Hercules Framwork</b>, cool plugin sentiment analysis with Naive Bayes on PHP by <a href="http://toddnestor.com">Todd D. Nestor</a>.
Author: Dwi Purwanto - dwipurwanto.210@gmail.com
Author URI: http://dwpr.github.io/
Version: 1 to final
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

// Exit if accessed directly
//jika diakss langsung lewat url tidak boleh (direk)
if( !defined( 'ABSPATH' ) )
{
	echo "Oops! No direct access please :)";
	exit;
}

//memembutuhkan file pendukung lain
//load hercules framwork (HF)
require_once( 'HF' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . 'utilities.php' );
require_once( 'HF' . DIRECTORY_SEPARATOR . 'autoload.php' );

$var_name = 'TAnalyzer Final';

global $var_name;
$var_name                   = new \Hercules\Framework;//global name Hercule\load
$var_name->plugin_directory = dirname( __FILE__ );

$var_name->InitiateAll();