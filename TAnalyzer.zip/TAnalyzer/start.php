<?php

require_once( 'hercules-framework' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . 'utilities.php' );
require_once( 'hercules-framework' . DIRECTORY_SEPARATOR . 'autoload.php' );