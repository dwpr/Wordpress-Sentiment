<?php namespace Hercules;

class Helper extends HercAbstract
{
    function __construct()
    {

    }
}