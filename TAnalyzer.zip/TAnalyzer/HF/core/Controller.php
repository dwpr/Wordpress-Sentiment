<?php namespace Hercules;

class Controller extends HercAbstract
{
    function __construct()
    {

    }
}