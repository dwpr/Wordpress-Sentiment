<?php

use Hercules\View;


class HercView_SentimentAnalysis extends View
{

	/**
	 * Sets the main data used byt hte framework and some other variables used in just this class.
	 */

    function __construct()
    {
        $this->directory         = dirname( __FILE__ );
        $this->name              = 'Sentiment Analysis';
        $this->type              = 'post-columns';
        $this->class_name        = __CLASS__;

		//Defines what post types the sentiment columns will be added to.
		$this->post_type = array('all');
        $this->data = array();
        parent::__construct();
    }

	/**
	 * Defines the array of columns to add to the the post list tables.
	 *
	 * @return array columns we want to add to the post list tables.
	 */
    function PostsColumns()
    {
        return array(
			'post-sentiment' => 'Post Sentiment'
        );
    }

	/**
	 * Sets the function to handle printing data to the post content sentiment column in the posts list tables.
	 *
	 * @return String Sentiment string to display in the post content sentiment column.
	 */
	function PostSentimentFilter()
	{
		global $post;
		$id_post_comment = $post->ID;
		if($post->comment_count==0){ //jika counter komen masih 0 atau ada komen tetapi belum di approved
			echo "Belum ada komen / komen belum diapproved";
		}else{			
			$json = file_get_contents("http://localhost:5000/status_post?id_post_comment=".$id_post_comment);
			$dataservice = json_decode($json, true);
			// print_r($dataservice);
			if($dataservice==NULL or empty($dataservice)){
				echo "Belum ada komen dalam artikel ini / API olah data tidak jalan";
				// echo $id_post_comment;
			}else{
				if($post->comment_count==NULL or empty($post->comment_count)){
					echo "Belum ada komen dalam artikel ini";
				}else{
					foreach ($dataservice as $value) {
						// v1
						// $ini = "
						// <a href='#' data-toggle='tooltip' data-placement='top' title='klik untuk melihat detailnya' class='lihat'>".$value["status"][0]."</a>
						// ";
						// echo $ini;

						// v2
						$ini = "positif = ".$value["percent_pos"]."<br>netral = ".$value["percent_net"]."<br>negatif = ".$value["percent_neg"]."";
						echo $ini;
					}
				}
			}
		}
	}

	/**
	 * Defines the array of columns to add to the comment list table.
	 *
	 * @return array columns we want to add to the comment list table.
	 */
	function CommentsColumns()
	{
		return array(
			'comment-sentiment' => 'Sentiment'
		);
	}

	/**
	 * Sets the function to handle printing data to the sentiment column on the comments list table.
	 *
	 * @return String Sentiment string to display in the comment sentiment column.
	 */
	function CommentSentimentFilter()
	{
		global $comment;
		$id_comment = $comment->comment_ID;
		if($comment->comment_approved==0){ //jika belum komen belum diapproved
			echo "Komentar ini belum diapproved, API tidak dapat mengolah";
		} else{
			$json = file_get_contents("http://localhost:5000/olah_data?id_comment=".$id_comment);
			$time_start = microtime(true);
			// print_r($http_response_header);
			$dataservice = json_decode($json, true);
			// print_r($dataservice);
			if($dataservice==NULL or empty($dataservice)){
				echo "Belum ada komen dalam artikel ini / API olah data tidak jalan";
			}else{
				foreach ($dataservice as $value) {	
					echo $value["status"][0];
					// echo "<br>".(microtime(true)-$time_start); //tracker waktu eksekusi
					// print_r($dataservice);
				}
			}
		}
	}
}