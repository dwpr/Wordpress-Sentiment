<div class="herc-bootstrap" id="herc_posts_list">
    <textarea name="notes" class="form-control" rows="10" style="height:214px;">{{notes}}</textarea>
</div>