from flask import Flask, jsonify, request
from flaskext.mysql import MySQL
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity  

stemmer = StemmerFactory().create_stemmer()
remover = StopWordRemoverFactory().create_stop_word_remover()

mysql = MySQL()
vectorizer = TfidfVectorizer(smooth_idf=False, norm=None)

app = Flask(__name__)
import MySQLdb
import pandas as pd
import nltk

mysql.init_app(app)

@app.route('/')  #3
def home():
	return '<b>Hello, this is API for my final application :)</b>'

@app.route("/status_post")
def status_post():
	# untuk sementara baca dari file csv dulu, kedepan atau next dev bisa pakai db pada server atau apalah :D
	get_statcsv = pd.read_csv("status_post.csv");


@app.route("/olah_data")
def olah_data():
	# ambil database
    konek = MySQLdb.connect("localhost","root","","wordpress")
    # menggunakan method cursor()
    Eksekusi = konek.cursor()
    Eksekusi2 = konek.cursor()
    # deklarasikan sql query
    parameter = request.args.get('id_comment','')
    sqlselect = "SELECT * FROM wp_comments where comment_approved='1' and comment_ID='%s'"%parameter
    userkomen = "SELECT comment_author from wp_comments"
    # Eksekusi MySQL menggunakan method execute()
    Eksekusi.execute(sqlselect)
    Eksekusi2.execute(userkomen)
    data = Eksekusi.fetchall() #tampilkan dengan fetchall
    data2 = Eksekusi2.fetchall() #tampilkan author komen dengan fetchall
    test_set_data = [] #datalist
    author = [] #author komen
    for aut in data2:
    	author.append(aut)
    for ambil in data:
    	test_set_data.append(ambil[8]) # masukkan ke list data uji
	# test_set = ["Bagus, Lanjutkan ! saya tunggu update tulisan selanjutnya"] #Query
	# train_set = ["Artikel dari blog ini sangat bagus","Tulisannya sangat menginspirasi","Penulisan blognya kurang rapi","Artikel ini terlalu panjang dengan sedikit gambar"] #Documents
	train_set_data = pd.read_csv("dataset_500_final.csv") #baca data latih
	train_set = [str(x) for x in list(train_set_data["Hasil_preprocess"])] #ubah dalam bentuk list

	katabaku = pd.read_csv('vocab_katabaku.csv')
	baku = [x for x in katabaku["kata_baku"]]
	query = test_set_data #list query
	pre_process = []
	for teks in query:
	    kecil = teks.lower() # kecilkan semua teks
	    textStemmed = stemmer.stem(kecil)  #stemming teks
	    textClean = remover.remove(textStemmed) #teks stopword remover
	    convert_to_string = "".join(textClean) #harus string dikasih koma atau tanda baca lain untuk mengatasi entering dan setiap kalimat
	    word = nltk.word_tokenize(convert_to_string) #split string yang sudah dikonversi
	    tampung = []
	    for teks_conv in word:
	        n=0
	        for j in katabaku["vocabulary"]:
	            if teks_conv == j:
	                teks_conv = baku[n]
	            n=n+1
	        tampung.append(teks_conv) #tampung setia string kedalam list (list string)
	    pre_process.append(" ".join(tampung)) #join setiap list string dengan spasi

	gabung = pre_process+train_set #gabungkan query (data uji) dengan data latih
	#preprocess dahulu karena itu adalah query dan diletakkan dipaling depan

	# mencari kosim
	XX = vectorizer.fit_transform(gabung)
	cosine = cosine_similarity(XX,XX[0:1])

	tabel_kosim = pd.DataFrame(cosine[1:]) # tabel hasil perhitungan kosim
	tabel_data = pd.DataFrame(train_set_data) # tabel data latih
	tabel_final = pd.concat([tabel_data,tabel_kosim],axis=1) # satukan jadi 1 tabel
	nama = ["Komentar","Sentimen","Hasil_preprocess","Cosime"] #nama kolom
	tabel_final.columns = nama #submit header nama kolom
	urut = tabel_final.sort_values(by=["Cosime"],ascending=False) # tabel diurutkan berdasarkan kolom Cosime secara Descending (besar ke kecil)

	# klasifikasi
	pea=[]
	def rekursif(batas_bawah,batas_atas):
	    if(batas_bawah<=batas_atas):
	        pol = urut.reset_index(drop=True) # reset index tabel
	        res = pol[0:batas_bawah]
	        print res
		    # hitung status
	        i=0
	        total_negatif=0
	        total_netral=0
	        total_positif=0
	        for io in res["Sentimen"]:
	            if(pol["Sentimen"][i]==0):
	                total_negatif+=1
	            elif (res["Sentimen"][i]==1):
	                total_netral+=1
	            else:
	                total_positif+=1
	            i=i+1
	        # penentuan status
	        status = []
	        if (total_negatif>total_netral and total_negatif>total_positif):
	            status.append("negatif")
	        elif (total_netral>total_negatif and total_netral>total_positif):
	            status.append("netral")
	        elif (total_positif>total_negatif and total_positif>total_netral):
	            status.append("positif")
	        elif (total_negatif == total_netral or total_negatif==total_positif or total_netral==total_positif):
	            status.append("netral")
	        pea.append(status) # masukkan status kedalam list pea
	        batas_bawah=batas_bawah+1
	        rekursif(batas_bawah,batas_atas) # rekursif, panggil dirinya sendiri
	rekursif(3,20) #coba 
	# print jumlah pea
	az = pea.count(['positif']) # hitung jumlah status positif dalam lis pea
	ac = pea.count(['negatif']) # hitung jumlah status negatif dalam lis pea
	ax = pea.count(['netral']) # hitung jumlah status netral dalam lis pea
	# penentuan pea
	if(az>ac and az>ax):
	    status_pea = str("positif")
	elif(ac>az and ac>ax):
		status_pea = str("negatif")
	elif(ax>ac and ax>az):
		status_pea = str("netral")

	tampil = []
	for datanya in data:
		datanya = {
                'Comment_ID': datanya[0],
                'Comment_Post_ID': datanya[1],
                'Comment': datanya[8],
                'status':status_pea}
        tampil.append(datanya)#masukkan data kedalam var array tampil
    return jsonify(tampil)

if __name__ == '__main__': #4
   app.run(debug=True)