# -*- coding: utf-8 -*-
# kode diatas berrguna untuk mngizinkan karakter ascii, dalam kasus ini untuk regex remove link dibawah
from flask import Flask, jsonify, request
from flaskext.mysql import MySQL
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity  

stemmer = StemmerFactory().create_stemmer()
remover = StopWordRemoverFactory().create_stop_word_remover()

mysql = MySQL()
vectorizer = TfidfVectorizer(smooth_idf=False, norm=None)

app = Flask(__name__)
import MySQLdb
import pandas as pd
import nltk
import re
import csv

mysql.init_app(app)

@app.route('/')  #3
def home():
	return '<b>Hello, this is API for my final application :)</b>'

@app.route("/status_post")
def status_post():
	# untuk sementara baca dari file csv dulu, kedepan atau next dev bisa pakai db pada server atau apalah :D
	get_statcsv = pd.read_csv("kesimpulan_post.csv")
	parameter = request.args.get('id_post_comment','')
	cek = get_statcsv["ID_Post"]
	i =0
	status = []
	while(i<len(cek)):
	    if(cek[i] == int(parameter)):
	        isinya = get_statcsv["Sentimen"][i]
	        if(isinya==0):
	            status.append("0")
	        elif(isinya==1):
	            status.append("1")
	        elif(isinya==2):
	            status.append("2")
	    i+=1
	jum_neg = status.count("0")
	jum_net = status.count("1")
	jum_pos = status.count("2")
	jumlah_total = jum_pos+jum_net+jum_neg
	if(jumlah_total!=0): #jika tidak kosong
		percent_pos = round((float(jum_pos)/float(jumlah_total))*100,2)
		percent_net = round((float(jum_net)/float(jumlah_total))*100,2)
		percent_neg = round((float(jum_neg)/float(jumlah_total))*100,2)
	else:
		percent_pos = 0
		percent_net = 0
		percent_neg = 0

	tampilkan = []
	if(jum_pos>jum_neg and jum_pos>jum_net):
		tampilkan.append("positif")
	elif(jum_neg>jum_pos and jum_neg>jum_net):
		tampilkan.append("negatif")
	elif(jum_net>jum_neg and jum_net>jum_pos):
		tampilkan.append("netral")
	elif(jum_pos==jum_neg or jum_pos==jum_net or jum_neg==jum_net):
		tampilkan.append("netral")

	print tampilkan
	print type(tampilkan)

	tampil = []
	datanya = {
		"jum_pos":jum_pos,
		"jum_net":jum_net,
		"jum_neg":jum_neg,
		"percent_pos":str(percent_pos)+' %',
		"percent_net":str(percent_net)+' %',
		"percent_neg":str(percent_neg)+' %',
		'status':tampilkan
		}
	tampil.append(datanya)#masukkan data kedalam var array tampil
	return jsonify(tampil)


@app.route("/olah_data")
def olah_data():
	# klasifikasi
	def klasifikasi(stat,urut):
	    pea=[]
	    if (";" in stat): # for developng future, belum ditest fiks
	        pecah = stat.split(";")
	        batas_bawah = int(pecah[0])
	        batas_atas = int(pecah[1])
	        while (batas_bawah<=batas_atas):
	            pol = urut.reset_index(drop=True)
	            res = pol[0:batas_bawah]
	            i=0
	            total_negatif=0
	            total_netral=0
	            total_positif=0
	            for io in res["Sentimen"]:
	                if(pol["Sentimen"][i]==0):
	                    total_negatif+=1
	                elif (res["Sentimen"][i]==1):
	                    total_netral+=1
	                else:
	                    total_positif+=1
	                i=i+1
	            # hitung status
	            pre_status = []
	            if (total_negatif>total_netral and total_negatif>total_positif):
	                pre_status.append("negatif")
	            #     print "negatif"
	            elif (total_netral>total_negatif and total_netral>total_positif):
	                pre_status.append("netral")
	            #     print "netral"
	            elif (total_positif>total_negatif and total_positif>total_netral):
	                pre_status.append("positif")
	            elif (total_negatif == total_netral or total_negatif==total_positif or total_netral==total_positif):
	                pre_status.append("netral")
	            #     print "positif"
	            pea.append(pre_status)
	            batas_bawah=batas_bawah+1
	        # print pea
	        az = pea.count(['positif'])
	        ac = pea.count(['negatif'])
	        ax = pea.count(['netral'])
	        # status = []
	        if(az>ac and az>ax):
	            # print "status query positif"
	            status.append("positif")
	            predik.append("2")
	        elif(ac>az and ac>ax):
	            # print "status query negatif"
	            status.append("negatif")
	            predik.append("0")
	        elif(ax>ac and ax>az):
	            # print "status query netral"
	            status.append("netral")
	            predik.append("1")
	        elif(ax==ac or ax==az or ac==az):
	            status.append("netral")
	            predik.append("1")
	    else:
	        batas_bawah = int(stat)
	        pol = urut.reset_index(drop=True)
	        res = pol[0:batas_bawah]
	        # print res
	        # coba langsung hitung
	        i=0
	        total_negatif=0
	        total_netral=0
	        total_positif=0
	        for io in res["Sentimen"]:
	            if(pol["Sentimen"][i]==0):
	                total_negatif+=1
	            elif (res["Sentimen"][i]==1):
	                total_netral+=1
	            else:
	                total_positif+=1
	            i=i+1
	        # print "Neg = "+str(total_negatif)+", Netral = "+str(total_netral)+", Positif = "+str(total_positif)
	    	# hitung status
	        # status = []
	        if (total_negatif>total_netral and total_negatif>total_positif):
	            status.append("negatif")
	            predik.append("0")
	        #     print "negatif"
	        elif (total_netral>total_negatif and total_netral>total_positif):
	            status.append("netral")
	            predik.append("1")
	        #     print "netral"
	        elif (total_positif>total_negatif and total_positif>total_netral):
	            status.append("positif")
	            predik.append("2")
	        elif (total_negatif == total_netral or total_negatif==total_positif or total_netral==total_positif):
	            status.append("netral")
	            predik.append("1")
	        pea.append(status)

	def olah():		
		# jika belum diolah maka diolah dahulu
		train_set_data = pd.read_csv("900_100_label_uji.csv") #baca data latih
		train_set = [str(x) for x in list(train_set_data["Hasil_preprocess"])] #ubah dalam bentuk list

		katabaku = pd.read_csv('900_baku_new.csv')
		baku = [x for x in katabaku["baku"]]
		query = test_set_data #list query

		#remove link and number alias remover pertama
		remover_pertama = []
		for komentarnya in query:
		    remove_link = re.sub(r'''(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’]))''', " ", komentarnya)
		    remove_number = ''.join(filter(lambda s: not str(s).isdigit(),remove_link))
		    remover_pertama.append(remove_number)

		# remover author in query
		ga=[]
		for rem_pertama in remover_pertama:
			convert_to_strings = "".join(rem_pertama) #harus string dikasih koma atau tanda baca lain untuk mengatasi entering dan setiap kalimat
			words = nltk.word_tokenize(convert_to_strings) #split string yang sudah dikonversi
			for authornya in author:
				hasil_rem_author = [x for x in words if authornya not in x]
				maks = ' '.join(hasil_rem_author) #convert to string
			ga.append(maks)
			co = [x for x in ga if x] #removve blank list

		#remover kedua
		pre_process = []
		for teks in co:
		    kecil = teks.lower() # kecilkan semua teks
		    textStemmed = stemmer.stem(kecil)  #stemming teks
		    textClean = remover.remove(textStemmed) #teks stopword remover
		    convert_to_string = "".join(textClean) #harus string dikasih koma atau tanda baca lain untuk mengatasi entering dan setiap kalimat
		    word = nltk.word_tokenize(convert_to_string) #split string yang sudah dikonversi
		    tampung = []
		    for teks_conv in word:
		        n=0
		        for j in katabaku["term"]:
		            if teks_conv == j:
		                teks_conv = baku[n]
		            stem2 = stemmer.stem(teks_conv) #stem lagi jika bakunya belum tertulis kata dasar
		            n=n+1
		        tampung.append(stem2) #tampung setia string kedalam list (list string)
		    pre_process.append(" ".join(tampung)) #join setiap list string dengan spasi

		gabung = pre_process+train_set #gabungkan query (data uji) dengan data latih
		#preprocess dahulu karena itu adalah query dan diletakkan dipaling depan

		# mencari kosim
		XX = vectorizer.fit_transform(gabung)
		cosine = cosine_similarity(XX,XX[0:1])

		tabel_kosim = pd.DataFrame(cosine[1:]) # tabel hasil perhitungan kosim
		tabel_data = pd.DataFrame(train_set_data) # tabel data latih
		tabel_final = pd.concat([tabel_data,tabel_kosim],axis=1) # satukan jadi 1 tabel
		nama = ["id_post","Komentar","Sentimen","Hasil_preprocess","Cosime"] #nama kolom
		tabel_final.columns = nama #submit header nama kolom
		urut = tabel_final.sort_values(by=["Cosime"],ascending=False) # tabel diurutkan berdasarkan kolom Cosime secara Descending (besar ke kecil)

		#klasifikasi
		# predik = []
		# status = []
		nilai_ka = "4"
		klasifikasi(nilai_ka,urut)

		#masukkan data uji ke data latih yang baru alias auto tambah data latih :D
		tabel_id = pd.DataFrame(idp)
		tabel_kue = pd.DataFrame(query)
		tabel_prediksi = pd.DataFrame(predik)
		tabel_olah = pd.DataFrame(pre_process)

		#disable dahulu sementara
		gabung_tabel = pd.concat([tabel_id,tabel_kue,tabel_prediksi,tabel_olah], axis=1)
		nama = ["id_post","isi_komen","sentimen","Hasil_preprocess"]
		gabung_tabel.columns = nama
		# print gabung_tabel #for checker table
		#auto tambah data latih
		ekspor = train_set_data.append(gabung_tabel).reset_index(drop=True)
		namafile = "900_100_label_uji.csv"
		ekspor.to_csv(namafile,sep=",",index=False)

		#auto save for kesimpulan sentimen pos
		ComID = pd.DataFrame(cid)
		ComPostID = tabel_id
		Sentimen_fin = tabel_prediksi
		gabung_tabel_posfin = pd.concat([ComID,ComPostID,Sentimen_fin], axis=1)
		nama = ["Komen_ID","ID_Post","Sentimen"]
		gabung_tabel_posfin.columns = nama
		# print gabung_tabel_posfin
		#auto tambah kesimpulan
		baca_kesimpulan_csv = pd.read_csv("kesimpulan_post.csv")
		ekspor = baca_kesimpulan_csv.append(gabung_tabel_posfin).reset_index(drop=True)
		namafile = "kesimpulan_post.csv"
		ekspor.to_csv(namafile,sep=",",index=False)


	# ambil database
	konek = MySQLdb.connect("localhost","root","","wordpress")
	# menggunakan method cursor()
	Eksekusi = konek.cursor()
	# deklarasikan sql query
	parameter = request.args.get('id_comment','')
	sqlselect = "SELECT * FROM wp_comments where comment_approved='1' and comment_ID='%s'"%parameter
	# Eksekusi MySQL menggunakan method execute()
	Eksekusi.execute(sqlselect)
	data = Eksekusi.fetchall() #tampilkan dengan fetchall
	test_set_data = [] #datalist
	idp = []
	cid = []
	author = [] #author komen
	for ambil in data:
		test_set_data.append(ambil[8]) # masukkan komen ke list data uji
		cid.append(ambil[0]) #comment id
		idp.append(ambil[1]) #idpost
		author.append(ambil[3]) #masukkan author kedalam list


	# untuk sementara baca dari file csv dulu, kedepan atau next dev bisa pakai db pada server atau apalah :D
	get_statcsv = pd.read_csv("kesimpulan_post.csv")
	sudah = idp
	cari = get_statcsv[get_statcsv["ID_Post"].isin(sudah)] #get data komentar yang sesuai dengan id_postnya
	has_car = [str(x) for x in list(cari["Komen_ID"])] #get data id komen dalam post tersebut
	#filter buat non process jika sudah ada data dalam kesimpulan / sudah diolah
	if not has_car:
		#jika data awalan, kan kosong maka diolah dahulu. maksudnya jika dalam kesimpulan.csv masih kosong maka ini proses dijalankan
		print "data tidak ada"
		status=[]
		predik=[]
		olah()
	else:
		#otomatis data ada setelah olah. maksudnya jika kesimpulan.csv sudah ada data
		print "data "+str(cid[0])+" ada"
		data_ada = [x for x in has_car if str(cid[0]) in x]
		if data_ada:
			status_cari = "sesuai"
			print str(cid[0])+" === "+str(data_ada)
			#data ada dan sudah diolah maka tidak perlu diolah
			status = []
			i=0
			cari2 = cari.reset_index(drop=True) #untuk reset hasil pencarian
			while(i<len(cari2)):
				if(''.join(data_ada)==''.join(has_car[i])):  #dari list diubah kedalam string menggunakan join
					if(cari2["Sentimen"][i]==0):
						status.append("negatif")
					elif(cari2["Sentimen"][i]==1):
						status.append("netral")
					elif(cari2["Sentimen"][i]==2):
						status.append("positif")
				i+=1
		else:
			status_cari = "tidaksesuai"
			print str(cid[0])+" =/= "+str(data_ada)
			#data ada tetapi belum diolah
			status=[]
			predik=[]
			olah()
		print status_cari

	tampil = []
	for datanya in data:
		datanya = {
	            'Comment_ID': datanya[0],
	            'Comment_Post_ID': datanya[1],
	            'Comment': datanya[8],
	            'status':status}
		tampil.append(datanya)#masukkan data kedalam var array tampil
	# print tampil
	return jsonify(tampil)

	#reset opsional
	predik = []
	status = []

if __name__ == '__main__': #4
   app.run(debug=True)